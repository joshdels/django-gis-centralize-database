### Topmap Sync Plugin

This is a qgis plugin that loads all the project, sync all the project and edit the folder here......

This is an integration of the topmapsolutions project management for the sync

This is still in devlopment but i enjoy it :)

![TopmapSync QPlugin](resources/topmapsync.png)


```
QGIS
 └── TopMapSync (controller)
     ├── LoginDialog (modal, disposable)
     └── MainWindow (persistent)
         └── QStackedWidget
             ├── ProjectListPage
             ├── ProjectUploadPage
             └── ProjectDetailsPage
```
